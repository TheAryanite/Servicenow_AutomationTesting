import { test as bT } from "@playwright/test";
import { LoginPage } from "../pages/loginpage.ts";
import { HomePage } from "../pages/homepage.ts";
import { UsersPage } from "../pages/userspage.ts";

type myFixture = {
  loginfix: LoginPage;
  homfix: HomePage;
  usersfix: UsersPage;
};

export const test1 = bT.extend<myFixture>({
  loginfix: async ({ page }, use) => {
    const login = new LoginPage(page);
    await use(login);
  },

  homfix: async ({ page }, use) => {
    const hp = new HomePage(page);
    await use(hp);
  },

  usersfix: async ({ page }, use) => {
    const up = new UsersPage(page);
    await use(up);
  },
});

export { expect } from "@playwright/test";