import { test1 } from "../utility/customFixture";
import testData from "../Data/testData.json";

const d = (tcId: string) => testData.find((row) => row.TcId === tcId)!;

// Tc001 – Create User
test1(
  "[Tc001] Service now - Create User",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc001");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.clickNew();
    await usersfix.fillUserName(td.UserName);
    await usersfix.fillFirstName(td.FirstName);
    await usersfix.fillLastName(td.LastName);
    await usersfix.fillEmail(td.Email);
    await usersfix.clickInsert();

    await usersfix.page.waitForTimeout(6000);
    await usersfix.verifySuccessMessage(td.ExpectedMsg);
  }
);

// Tc002 – Duplicate User Validation
test1(
  "[Tc002] Service now - Duplicate User Validation",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc002");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.clickNew();
    await usersfix.fillUserName(td.UserName);
    await usersfix.clickInsert();

    await usersfix.verifyErrorMessage(td.ExpectedMsg);
    await usersfix.page.waitForTimeout(6000);
  }
);

// Tc003 – Edit User Details
test1(
  "[Tc003] Service now - Edit User Details",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc003");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.searchByUserId(td.SearchUserName);
    await usersfix.clickFirstResult();

    await usersfix.fillUserName(td.NewUserName);
    await usersfix.fillFirstName(td.NewFirstName);
    await usersfix.fillLastName(td.NewLastName);
    await usersfix.fillEmail(td.NewEmail);
    await usersfix.clickUpdate();

    await usersfix.searchByUserId(td.NewUserName);
    await usersfix.page.waitForTimeout(6000);

    await usersfix.verifyUserInList(
      td.NewUserName,
      td.ExpectedMsg,
      td.NewEmail
    );
  }
);

// Tc004 – Assign Role to User
test1(
  "[Tc004] Service now - Assign Role to User",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc004");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.searchByUserId(td.SearchUserName);
    await usersfix.clickFirstResult();

    await usersfix.openRolesTab();
    await usersfix.clickEditRoles();
    await usersfix.assignRole(td.RoleName);

    await usersfix.verifyRoleAssigned(td.RoleName);
  }
);


// Tc005 – Remove Role from User
test1(
  "[Tc005] Service now - Remove Role from User",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc005");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.searchByUserId(td.SearchUserName);
    await usersfix.clickFirstResult();

    await usersfix.openRolesTab();
    await usersfix.clickEditRoles();
    await usersfix.removeRole(td.RoleName);

    await usersfix.verifyRolesEmpty();
  }
);

// Tc006 – Assign Title to User

test1(
  "[Tc006] Service now - Assign Title to User",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc006");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.clickNew();
    await usersfix.fillUserName(td.UserName);
    await usersfix.fillTitle(td.Title);
    await usersfix.page.waitForTimeout(2000);
    await usersfix.clickInsert();
    await usersfix.page.waitForTimeout(10000);

    await usersfix.searchByUserId(td.UserName);
    await usersfix.clickFirstResult();

    await usersfix.verifyTitleField(td.ExpectedMsg);
  }
);

// Tc007 – Invalid Department Validation
test1(
  "[Tc007] Service now - Invalid Department Validation",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc007");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.clickNew();
    await usersfix.fillUserName(td.UserName);
    await usersfix.fillDepartment(td.Department);
    await usersfix.clickInsert();

    await usersfix.page.waitForTimeout(2000);
    await usersfix.verifyErrorMessage(td.ExpectedMsg);
  }
);

// Tc008 – Search User by Name
test1(
  "[Tc008] Service now - Search User by Name",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc008");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.openAdvancedFilter();
    await usersfix.addFilterCondition(td.FilterField, td.FilterValue, true);
    await usersfix.runFilter();

    await usersfix.verifySearchResultByName(td.ExpectedMsg);
  }
);

// Tc009 – Search Using Multiple Filters
test1(
  "[Tc009] Service now - Search Using Multiple Filters",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(90000);
    const td = d("Tc009");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.openAdvancedFilter();
    await usersfix.addFilterCondition(td.Filter1Field, td.Filter1Value, true);
    await usersfix.addFilterCondition(td.Filter2Field, td.Filter2Value, false);
    await usersfix.addFilterCondition(td.Filter3Field, td.Filter3Value, false);
    await usersfix.runFilter();

    await usersfix.verifyMultiFilterResults(
      td.Filter1Value,
      td.Filter2Value,
      td.Filter3Value
    );
    await usersfix.page.waitForTimeout(6000);
  }
);

// Tc010 – Delete User

test1(
  "[Tc010] Service now - Delete User",
  async ({ loginfix, homfix, usersfix }) => {
    test1.setTimeout(60000);
    const td = d("Tc010");

    await loginfix.goto();
    await loginfix.login();

    await homfix.navigateToModule("Users");
    await usersfix.navigateToUsers();

    await usersfix.clickNew();
    await usersfix.fillUserName(td.UserName);
    await usersfix.clickInsert();

    await usersfix.searchByUserId(td.UserName);
    await usersfix.clickFirstResult();
    await usersfix.page.waitForTimeout(4000);

    await usersfix.clickDelete();
    await usersfix.confirmDelete();

    await usersfix.verifyEmptyList();
    await usersfix.page.waitForTimeout(5000);
  }
);